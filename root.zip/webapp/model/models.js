sap.ui.define([
	"sap/ui/model/json/JSONModel"
], function(JSONModel) {
	"use strict";

	return {

		createDeviceModel: function() {
			var oModel = new JSONModel();
			oModel.loadData("localdata.json");
			oModel.setDefaultBindingMode("OneWay");
			return oModel;
		}

	};
});