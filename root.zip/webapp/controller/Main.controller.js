sap.ui.define(["root/controller/BaseController"
	],
	function (Controller,Model) {
		"use strict";
		return Controller.extend("root.controller.Main", {

			oCore: sap.ui.getCore(),

			onInit: function () {
				// setting up model
				
				
				// var oApp = this.getView().byId("idApp");
				// var oView1 = new sap.ui.view("view1", {
				// 	viewName: "root.view.View1",
				// 	type: sap.ui.core.mvc.ViewType.XML
				// });
				// var oView2 = new sap.ui.view("view2", {
				// 	viewName: "root.view.View2",
				// 	type: sap.ui.core.mvc.ViewType.XML
				// });
				// oApp.addMasterPage(oView1);
				// oApp.addDetailPage(oView2);
			}
		});
	});