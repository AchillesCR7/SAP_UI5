sap.ui.define(["root/controller/BaseController"
               
              ],
	function (Controller) {
		"use strict";
		return Controller.extend("root.controller.View1", {
			
			
			oCore: sap.ui.getCore(),

			onInit: function () {
				this.oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			},
			onPress:function(oEvent)
			{
			// var oItem = oEvent.getParameter("listItem")	;
			// var sPath = oItem.getBindingContextPath();
			// var oApp = this.getApp();
			// var oView2 = oApp.getDetailPages()[0];
			// oView2.bindElement(sPath);
		    this.oRouter.navTo("detail");
			},
			onSearch: function(oEvent){
				var queryStr = oEvent.getParameter("query");
				if(!queryStr) {
					queryStr = oEvent.getParameter("newValue");
				}
				var oList = this.getView().byId("fruits");
				var oFil = new sap.ui.model.Filter("name",
				                                   sap.ui.model.FilterOperator.Contains,
				                                   queryStr
				);
				var oFil1 = new sap.ui.model.Filter("type",
				                                   sap.ui.model.FilterOperator.Contains,
				                                   queryStr
				);
				var oMainFil = new sap.ui.model.Filter(
					{
						filters: [oFil,oFil1],
						and:false
					});
				var oFilter = [oMainFil];
				oList.getBinding("items").filter(oFilter);
			},
			onNext : function(){
				// var oApp = this.getApp();
				var oApp = this.getView().getParent();
				oApp.to("view2");
			}
		});
	});